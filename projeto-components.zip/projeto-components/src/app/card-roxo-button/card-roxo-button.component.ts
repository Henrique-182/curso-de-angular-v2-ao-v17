import { Component } from '@angular/core';

@Component({
  selector: 'app-card-roxo-button',
  templateUrl: './card-roxo-button.component.html',
  styleUrls: ['./card-roxo-button.component.scss']
})
export class CardRoxoButtonComponent {

}
